ddocument.addEventListener("DOMContentLoaded", function () {
    const faqItems = document.querySelectorAll(".FAQ__accordian");

    faqItems.forEach((item) => {
        const question = item.querySelector(".FAQ__title");
        const answer = item.querySelector(".FAQ__visible");

        question.addEventListener("click", function () {
            answer.classList.toggle("active");

            // Hide other open answers (optional)
            faqItems.forEach((otherItem) => {
                if (otherItem !== item) {
                    otherItem.querySelector(".FAQ__visible").classList.remove("active");
                }
            });
        });
    });

    // Smooth Scrolling for Anchor Links
    const links = document.querySelectorAll("a[href^='#']");
    links.forEach(link => {
        link.addEventListener("click", function (e) {
            e.preventDefault();
            const targetId = this.getAttribute("href").substring(1);
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop,
                    behavior: "smooth"
                });
            }
        });
    });

    // Mobile Menu Toggle (if needed)
    const menuButton = document.querySelector(".menu-button");
    const navMenu = document.querySelector(".nav-menu");
    if (menuButton && navMenu) {
        menuButton.addEventListener("click", () => {
            navMenu.classList.toggle("open");
        });
    }
});
